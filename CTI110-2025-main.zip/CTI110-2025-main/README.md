# JeannetteNC

Jeannette Low
jmlow@my.waketech.edu

This is my Wake Tech School Account. I am taking CTI-110 as a pre-req for CSC-121. CSC-121 is being taken as a course replacement for a course at NC State. 

This repository will hold Wake Tech School Assignments specific to CTI-110.

# About Me  
## My Interests
* Blacksmithing
* Speedcubing
* Spending time with my 2 dogs, 2 cats, and a snake
## My Websites
* [National Blacksmith Educational Group](www.abana.org)
  The ABANA site is very useful because it has links to many groups around the United States. It also connects blacksmiths with educational resources online and in person schools. Both types of resources are crucial for learning about blacksmithing in today's society.
* [World Cube Association](https://www.worldcubeassociation.org)
  The WCA site is really cool because it holds all the official records of speed cubing since the WCA was founded. Additionally, it also has a lot of information on the history of the sport and where to find competitions around the world. 
